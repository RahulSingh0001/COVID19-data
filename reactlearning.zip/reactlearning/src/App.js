import Login from '../src/container/User/Login'
import './App.css';

function App() {
    return ( <
        Login / >
    );
}

export default App;